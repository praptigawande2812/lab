import numpy as np

# Define NAND gate inputs with bias column
X = np.array([
    [-1, -1,  1],  # Bias is always 1
    [-1,  1,  1],
    [ 1, -1,  1],
    [ 1,  1,  1]
])

# NAND gate outputs (-1 instead of 0 for binary representation)
y_nand = np.array([1, 1, 1, -1])  # NAND = Negation of AND

# Initialize weights (including bias weight)
w_nand = np.array([0.0, 0.0, 0.0])  # Weights for x1, x2, and bias

# Learning rate
c = 1  

# Hebbian Learning Algorithm for NAND
print("Training NAND Gate:")
for i in range(len(X)):
    net = np.dot(w_nand, X[i])  # Compute net input
    w_nand += c * y_nand[i] * X[i]  # Update weights
    print(f"Input: {X[i]}, Output: {y_nand[i]}, Updated Weights: {w_nand}")

print("-" * 50)
print("Final NAND Weights:", w_nand)

# Binary activation function (sign function)
def signum(value):
    return 1 if value > 0 else -1

# Compute final outputs for NAND
print("\nNAND Gate Output:")
for i in range(len(X)):
    net = np.dot(w_nand, X[i])
    output = signum(net)
    print(f"Input: {X[i]}, Net: {net}, Output: {output}")