import numpy as np

# Define AND gate inputs with bias column
X = np.array([
    [-1, -1,  1],  # Bias is always 1
    [-1,  1,  1],
    [ 1, -1,  1],
    [ 1,  1,  1]
])

# AND gate outputs (-1 instead of 0 for binary representation)
y = np.array([-1, -1, -1, 1])  

# Initialize weights (including bias weight)
w = np.array([0.0, 0.0, 0.0])  # Weights for x1, x2, and bias

# Learning rate
c = 1  

# Hebbian Learning Algorithm
for i in range(len(X)):
    net = np.dot(w, X[i])  # Compute net input
    w += c * y[i] * X[i]   # Update weights
    print(f"Input: {X[i]}, Output: {y[i]}, Updated Weights: {w}")

print("-" * 50)
print("Final Weights:", w)

# Binary activation function (sign function)
def signum(value):
    return 1 if value > 0 else -1

# Compute net and output for all inputs
print("\nFinal Output Calculation:")
for i in range(len(X)):
    net = np.dot(w, X[i])
    output = signum(net)
    print(f"Input: {X[i]}, Net: {net}, Output: {output}")