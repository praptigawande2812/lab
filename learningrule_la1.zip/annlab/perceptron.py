import numpy as np

X = np.array([
    [1, -2, 0, 1],   
    [0, 1.5, -0.5, -1],   
    [-1, 1, 0.5, -1]   
])

d = np.array([-1, -1, 1])  


w = np.array([1, -1, 0, 0.5]) 
learning_rate = 0.1


def signum(value):
    if value > 0:
        return 1
    elif value < 0:
        return -1
    else:
        return 0


for i in range(len(X)):
    net = np.dot(w, X[i])  
    print(f"Net: {net}")
    o = signum(net)  
    if o != d[i]:  
        w = w + learning_rate * (d[i] - o) * X[i]
    print(f"Input: {X[i]}, Output: {o}, Updated Weights: {w}")
print("-" * 50)


print("Final Weights:", w)






































