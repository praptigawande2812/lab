import numpy as np

# Input features
X = np.array([
    [2, 1, -1],   
    [0, -1, -1]  
])

# Target values
d = np.array([-1, 1])

# Initial weights (include bias as part of the weights)
w = np.array([0, 1, 0])

# Learning rate
learning_rate = 1

# Widrow-Hoff (Delta) Learning Rule
for i in range(len(X)):
    net = np.dot(w, X[i])  # Compute net input
    output = net  # Linear activation function (identity)
    error = d[i] - output  # Compute error
    
    # Update weights: w = w + learning_rate * error * X[i]
    w += learning_rate * error * X[i]
    
    # Output results for each iteration
    print(f"Input: {X[i]}, Target: {d[i]}, Output: {output}, Error: {error}, Updated Weights: {w}")
    print("-" * 50)

print("Final Weights:", w)
