import numpy as np

# Define NOT gate inputs with bias column
X = np.array([
    [-1,  1],  # Bias is always 1
    [ 1,  1]
])

# NOT gate outputs (-1 instead of 0 for binary representation)
y_not = np.array([1, -1])  # NOT Gate (flips input)

# Initialize weights (including bias weight)
w_not = np.array([0.0, 0.0])  # Weights for x1 and bias

# Learning rate
c = 1  

# Hebbian Learning Algorithm for NOT
print("Training NOT Gate:")
for i in range(len(X)):
    net = np.dot(w_not, X[i])  # Compute net input
    w_not += c * y_not[i] * X[i]  # Update weights
    print(f"Input: {X[i]}, Output: {y_not[i]}, Updated Weights: {w_not}")

print("-" * 50)
print("Final NOT Weights:", w_not)

# Binary activation function (sign function)
def signum(value):
    return 1 if value > 0 else -1

# Compute final outputs for NOT
print("\nNOT Gate Output:")
for i in range(len(X)):
    net = np.dot(w_not, X[i])
    output = signum(net)
    print(f"Input: {X[i]}, Net: {net}, Output: {output}")