import numpy as np

# Input vectors as column matrices
X = [
    np.array([[1], [-2], [1.5], [0]]), 
    np.array([[1], [-0.5], [-2], [1.5]]), 
    np.array([[0], [1], [-1], [-1.5]])
]

# Initial weight vector as a column matrix
w = np.array([[1], [-1], [0], [0.5]])

# Learning rate and lambda
c = 1  
lambda_ = 1  

# Activation function
def activation(net, lambda_):
    return (2 / (1 + np.exp(-lambda_ * net))) - 1

# Continuous Hebbian Learning
for i in range(len(X)):
    net = np.dot(w.T, X[i])  # Compute net input (dot product)
    net_scalar = net.item()  # Convert single value matrix to scalar
    print(f"Net: {net_scalar}")

    o = activation(net_scalar, lambda_)  # Compute activation output
    w = w + (c * o * X[i])  # Continuous Hebbian weight update
    print(f"Input: \n{X[i]}\nOutput: {o}\nUpdated Weights: \n{w}\n")

print("-" * 50)
print("Final Weights: \n", w)