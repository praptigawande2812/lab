import tkinter as tk
from PIL import Image, ImageDraw, ImageOps
import numpy as np
import tensorflow as tf
from scipy.ndimage import center_of_mass, shift
from tensorflow.keras.utils import to_categorical

# Train a simple model on MNIST (optional: you can save/load instead)
(x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()
x_train = x_train.reshape(-1, 784) / 255.0
x_test = x_test.reshape(-1, 784) / 255.0
y_train = to_categorical(y_train, 10)
y_test = to_categorical(y_test, 10)

# Initialize model
model = tf.keras.Sequential([
    tf.keras.Input(shape=(784,)),
    tf.keras.layers.Dense(128, activation='relu'),
    tf.keras.layers.Dense(64, activation='relu'),
    tf.keras.layers.Dense(10, activation='softmax')
])
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
model.fit(x_train, y_train, epochs=5, batch_size=128, validation_split=0.2, verbose=0)

# Main App
class DigitRecognizer:
    def __init__(self, master):
        self.master = master
        self.master.title("Draw a Digit (0–9)")
        self.canvas = tk.Canvas(master, width=200, height=200, bg='white')
        self.canvas.pack()
        self.button_frame = tk.Frame(master)
        self.button_frame.pack()
        self.predict_btn = tk.Button(self.button_frame, text="Predict", command=self.predict_digit)
        self.predict_btn.grid(row=0, column=0)
        self.clear_btn = tk.Button(self.button_frame, text="Clear", command=self.clear_canvas)
        self.clear_btn.grid(row=0, column=1)
        self.result_label = tk.Label(master, text="", font=("Helvetica", 24))
        self.result_label.pack()
        self.canvas.bind("<B1-Motion>", self.draw)
        self.last_x, self.last_y = None, None
        self.image = Image.new("L", (200, 200), 255)
        self.draw_image = ImageDraw.Draw(self.image)

    def draw(self, event):
        if self.last_x and self.last_y:
            self.canvas.create_line(self.last_x, self.last_y, event.x, event.y, width=10, fill='black', capstyle=tk.ROUND, smooth=True)
            self.draw_image.line([self.last_x, self.last_y, event.x, event.y], fill=0, width=10)
        self.last_x = event.x
        self.last_y = event.y

    def clear_canvas(self):
        self.canvas.delete("all")
        self.image = Image.new("L", (200, 200), 255)
        self.draw_image = ImageDraw.Draw(self.image)
        self.result_label.config(text="")
        self.last_x, self.last_y = None, None

    def preprocess_image(self, img):
        # Resize to 28x28, invert (white on black), and center it
        img = img.resize((28, 28), Image.Resampling.LANCZOS)
        img = ImageOps.invert(img)

        # Convert to numpy array and threshold
        img = np.array(img)
        img = (img > 50) * 255  # binarize (optional but improves clarity)
        
        # Center the digit using center of mass
        cy, cx = center_of_mass(img)
        shift_y, shift_x = np.array(img.shape) // 2 - np.array([cy, cx])
        img = shift(img, shift=(shift_y, shift_x), mode='constant', cval=0)
        
        # Normalize
        img = img.astype("float32") / 255.0
        img = img.reshape(1, 784)
        return img

    def predict_digit(self):
        processed = self.preprocess_image(self.image.copy())
        pred = model.predict(processed)
        digit = np.argmax(pred)
        confidence = np.max(pred)
        self.result_label.config(text=f"Prediction: {digit} ({confidence*100:.2f}%)")

        # Ask user if prediction is correct and retrain model
        self.ask_for_correction(digit)

    def ask_for_correction(self, predicted_digit):
        correction_window = tk.Toplevel(self.master)
        correction_window.title("Correct Prediction")
        
        label = tk.Label(correction_window, text=f"Predicted: {predicted_digit}. Is it correct?")
        label.pack()
        
        correct_btn = tk.Button(correction_window, text="Yes", command=lambda: correction_window.destroy())
        correct_btn.pack(side="left")
        
        incorrect_btn = tk.Button(correction_window, text="No", command=lambda: self.retrain_model(predicted_digit, correction_window))
        incorrect_btn.pack(side="right")
    
    def retrain_model(self, predicted_digit, window):
        # Ask for the correct digit
        retrain_window = tk.Toplevel(self.master)
        retrain_window.title("Enter Correct Digit")
        
        label = tk.Label(retrain_window, text="Enter the correct digit (0-9):")
        label.pack()

        digit_entry = tk.Entry(retrain_window)
        digit_entry.pack()

        def retrain_and_close():
            correct_digit = int(digit_entry.get())
            if correct_digit >= 0 and correct_digit <= 9:
                self.update_model(predicted_digit, correct_digit)
                retrain_window.destroy()
                window.destroy()
                self.result_label.config(text="Model Retrained!")
            else:
                label.config(text="Invalid digit, please enter a number between 0-9.")
        
        retrain_btn = tk.Button(retrain_window, text="Retrain", command=retrain_and_close)
        retrain_btn.pack()

    def update_model(self, predicted_digit, correct_digit):
        # Update the training dataset with the incorrect prediction and retrain the model
        global x_train, y_train

        # Add the new data (we add the processed image of the incorrect prediction)
        processed = self.preprocess_image(self.image.copy())

        # Append to the training dataset
        x_train = np.vstack([x_train, processed])
        y_train = np.vstack([y_train, to_categorical(correct_digit, 10)])

        # Retrain the model with the updated data
        model.fit(x_train, y_train, epochs=1, batch_size=128, verbose=0)
        print(f"Retrained with new data: Predicted {predicted_digit}, Correct {correct_digit}")

# Run the GUI
root = tk.Tk()
app = DigitRecognizer(root)
root.mainloop()
