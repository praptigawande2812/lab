import numpy as np

# Define NOR gate inputs with bias column
X = np.array([
    [-1, -1,  1],  # Bias is always 1
    [-1,  1,  1],
    [ 1, -1,  1],
    [ 1,  1,  1]
])

# NOR gate outputs (-1 instead of 0 for binary representation)
y_nor = np.array([1, -1, -1, -1])  # NOR = Negation of OR

# Initialize weights (including bias weight)
w_nor = np.array([0.0, 0.0, 0.0])  # Weights for x1, x2, and bias

# Learning rate
c = 1  

# Hebbian Learning Algorithm for NOR
print("Training NOR Gate:")
for i in range(len(X)):
    net = np.dot(w_nor, X[i])  # Compute net input
    w_nor += c * y_nor[i] * X[i]  # Update weights
    print(f"Input: {X[i]}, Output: {y_nor[i]}, Updated Weights: {w_nor}")

print("-" * 50)
print("Final NOR Weights:", w_nor)

# Binary activation function (sign function)
def signum(value):
    return 1 if value > 0 else -1

# Compute final outputs for NOR
print("\nNOR Gate Output:")
for i in range(len(X)):
    net = np.dot(w_nor, X[i])
    output = signum(net)
    print(f"Input: {X[i]}, Net: {net}, Output: {output}")