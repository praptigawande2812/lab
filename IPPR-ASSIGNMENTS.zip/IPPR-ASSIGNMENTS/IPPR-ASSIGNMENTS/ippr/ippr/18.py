# 18) Write a code for demonstrating Image arithmetic
# Input: Two Gray scale 8 bit images
# Expected output: Gray scale 8 bit image by applying
# i) Addition of two Images
# ii) Subtraction of two Images

import cv2
import numpy as np

# Load two grayscale images
image1 = cv2.imread('input_image.jpg', cv2.IMREAD_GRAYSCALE)
image2 = cv2.imread('image.jpg', cv2.IMREAD_GRAYSCALE)

if image1 is None or image2 is None:
    print("Error: One or both images not found or could not be opened.")
    exit()

# Resize image2 to the same size as image1
image2_resized = cv2.resize(image2, (image1.shape[1], image1.shape[0]))

# Perform image addition
added_image = cv2.add(image1, image2_resized)

# Perform image subtraction
subtracted_image = cv2.subtract(image1, image2_resized)

# Display the results
cv2.imshow("Added Image", added_image)
cv2.imshow("Subtracted Image", subtracted_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Save the results
cv2.imwrite('added_image.jpg', added_image)
cv2.imwrite('subtracted_image.jpg', subtracted_image)
