# 5) Write a code for obtaining edge detection of the Image using Prewitt
# operator
# Input: 24 bit RGB image
# Expected Output: Segmented Image
import cv2
import numpy as np

# Load and convert to grayscale
image = cv2.imread('input_image.jpg')
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Define Prewitt kernels
kernel_x = np.array([[ -1,  0,  1],
                     [ -1,  0,  1],
                     [ -1,  0,  1]], dtype=np.float32)

kernel_y = np.array([[  1,   1,   1],
                     [  0,   0,   0],
                     [ -1,  -1,  -1]], dtype=np.float32)

# Apply kernels using filter2D
prewitt_x = cv2.filter2D(gray, -1, kernel_x)
prewitt_y = cv2.filter2D(gray, -1, kernel_y)

# Combine both directions
prewitt_combined = cv2.magnitude(np.float32(prewitt_x), np.float32(prewitt_y))
prewitt_combined = np.uint8(np.clip(prewitt_combined, 0, 255))

# Display or save the result
cv2.imshow("Prewitt Edge Detection", prewitt_combined)
cv2.imwrite("prewitt_edges.jpg", prewitt_combined)
cv2.waitKey(0)
cv2.destroyAllWindows()
