# 10) Write a code for demonstrating Image transformation: Translation
# Input: 24 bit RGB image
# Expected Output:
# i) 24 bit RGB image shifted to right by 20 units
# ii) 24 bit RGB image shifted to downwards by 10 units


##///
import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the RGB image
image = cv2.imread('input_image.jpg')
if image is None:
    raise FileNotFoundError("Image file not found. Please check the path.")

# Convert BGR (OpenCV default) to RGB for display
image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

# Get image dimensions
rows, cols = image.shape[:2]

# Define translation matrices
# i) Shift right by 20 units
M_right = np.float32([[1, 0, 20], [0, 1, 0]])

# ii) Shift down by 10 units
M_down = np.float32([[1, 0, 0], [0, 1, 10]])

# Apply affine transformations
shifted_right = cv2.warpAffine(image, M_right, (cols, rows))
shifted_down = cv2.warpAffine(image, M_down, (cols, rows))

# Convert for display
shifted_right_rgb = cv2.cvtColor(shifted_right, cv2.COLOR_BGR2RGB)
shifted_down_rgb = cv2.cvtColor(shifted_down, cv2.COLOR_BGR2RGB)

# Display the images using matplotlib
plt.figure(figsize=(12, 4))

plt.subplot(1, 3, 1)
plt.title('Original Image')
plt.imshow(image_rgb)
plt.axis('off')

plt.subplot(1, 3, 2)
plt.title('Shifted Right by 20')
plt.imshow(shifted_right_rgb)
plt.axis('off')

plt.subplot(1, 3, 3)
plt.title('Shifted Down by 10')
plt.imshow(shifted_down_rgb)
plt.axis('off')

plt.tight_layout()
plt.show()