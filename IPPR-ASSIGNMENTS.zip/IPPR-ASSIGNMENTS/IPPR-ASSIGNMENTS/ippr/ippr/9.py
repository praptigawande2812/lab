# 9) Write a code for demonstrating Image transformation: Scaling
# Input: 24 bit RGB image
# Expected Output:
# i) 24 bit RGB image scaled by factor 2
# ii) 24 bit RGB image scaled by factor 0.5

import cv2
import numpy as np

# Load the image
image = cv2.imread('input_image.jpg')  # Replace with your image path

if image is None:
    print("Error: Image not found or could not be opened.")
    exit()

# Scale by 2x (enlarge)
scaled_up = cv2.resize(image, None, fx=2, fy=2, interpolation=cv2.INTER_LINEAR)

# Scale by 0.5x (shrink)
scaled_down = cv2.resize(image, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)

# Save results
cv2.imwrite('scaled_up.jpg', scaled_up)
cv2.imwrite('scaled_down.jpg', scaled_down)

# Display images
cv2.imshow("Original", image)
cv2.imshow("Scaled Up (2x)", scaled_up)
cv2.imshow("Scaled Down (0.5x)", scaled_down)

cv2.waitKey(0)
cv2.destroyAllWindows()
