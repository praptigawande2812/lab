# 4) Write a code for obtaining edge detection of the Image using Sobel
# operator
# Input: 24 bit RGB image
# Expected Output: Segmented Image
import cv2
import numpy as np

# Load the image and convert to grayscale
image = cv2.imread('input_image.jpg')
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply Sobel operator in X and Y direction
sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)

# Combine both directions
sobel_combined = cv2.magnitude(sobel_x, sobel_y)
sobel_combined = np.uint8(np.clip(sobel_combined, 0, 255))

# Display or save the result
cv2.imshow("Sobel Edge Detection", sobel_combined)
cv2.imwrite("sobel_edges.jpg", sobel_combined)
cv2.waitKey(0)
cv2.destroyAllWindows()
