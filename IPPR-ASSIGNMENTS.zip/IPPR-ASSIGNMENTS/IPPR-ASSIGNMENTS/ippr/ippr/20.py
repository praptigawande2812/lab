# 20) Write a code for demonstrating Image smoothening/Low pass filtering.
# Input: 24 bit RGB Noisy image
# Expected output: 24 bit RGB smooth image

import cv2
import numpy as np

# Load the noisy RGB image
image = cv2.imread('input_image.jpg')

if image is None:
    print("Error: Image not found or could not be opened.")
    exit()

# Apply Gaussian blur to smooth the image (low-pass filter)
smoothed_image = cv2.GaussianBlur(image, (5, 5), 0)

# Display the smoothed image
cv2.imshow("Smoothed Image", smoothed_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Save the smoothed image
cv2.imwrite('smoothed_image.jpg', smoothed_image)
