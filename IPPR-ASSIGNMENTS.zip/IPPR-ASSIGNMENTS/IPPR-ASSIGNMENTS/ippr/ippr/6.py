# 6) Write a code for obtaining edge detection of the Image using Canny
# operator
# Input: 24 bit RGB image
# Expected Output: Segmented Image

import cv2

# Load and convert to grayscale
image = cv2.imread('input_image.jpg')
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply Canny edge detection
edges = cv2.Canny(gray, threshold1=100, threshold2=200)

# Display and save
cv2.imshow('Canny Edge Detection', edges)
cv2.imwrite('canny_edges.jpg', edges)
cv2.waitKey(0)
cv2.destroyAllWindows()
