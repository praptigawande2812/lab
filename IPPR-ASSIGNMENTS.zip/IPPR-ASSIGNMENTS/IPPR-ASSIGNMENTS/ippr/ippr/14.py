# 14) Write a code for demonstrating Image Transformation from spatial
# domain into frequency domain. Apply DWT transformation. Display Original
# Image and Image retried after inverse (IDWT) transform
# Input: 24 bit RGB image
# Expected Output: PSNR value comparing Original Image and IDWT Image

# pip install pywavelets
import cv2
import numpy as np
import pywt

# Load the image
image = cv2.imread('input_image.jpg')  # Replace with your image path

if image is None:
    print("Error: Image not found or could not be opened.")
    exit()

# Convert image to grayscale
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply DWT (Discrete Wavelet Transform)
# Using 'haar' wavelet (can use other wavelets like 'db1', 'db2', etc.)
coeffs2 = pywt.dwt2(gray_image, 'haar')

# Extract approximation and details (horizontal, vertical, diagonal)
LL, (LH, HL, HH) = coeffs2

# Reconstruct image using inverse DWT
idwt = pywt.idwt2((LL, (LH, HL, HH)), 'haar')

# Convert idwt result to uint8 (if necessary)
idwt_image = np.uint8(np.clip(idwt, 0, 255))  # Clip values to [0, 255] and convert to uint8

# Resize idwt_image to match the original image size (if necessary)
idwt_image_resized = cv2.resize(idwt_image, (gray_image.shape[1], gray_image.shape[0]))

# Compute PSNR between original and resized IDWT image
psnr_value = cv2.PSNR(gray_image, idwt_image_resized)

# Display images
cv2.imshow("Original Image", gray_image)
cv2.imshow("Image after IDWT", idwt_image_resized)

print(f"PSNR between Original and IDWT Image: {psnr_value} dB")

cv2.waitKey(0)
cv2.destroyAllWindows()
