# 12) Write a code for demonstrating Image Compression. Apply Jpeg
# compression with suitable factor. Display Original Image and Decompressed
# Image
# Input: 24 bit RGB image
# Expected Output: PSNR value comparing Original Image and Decompressed
# Image

import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the image
image = cv2.imread('input_image.jpg')  # Replace with your image path

if image is None:
    print("Error: Image not found or could not be opened.")
    exit()

# Apply JPEG compression with a quality factor (0 to 100)
encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 50]  # Adjust quality factor (50 for compression)
result, encimg = cv2.imencode('.jpg', image, encode_param)

# Decode the image back from compressed JPEG format
decompressed_image = cv2.imdecode(encimg, 1)

# Compute PSNR (Peak Signal-to-Noise Ratio)
psnr_value = cv2.PSNR(image, decompressed_image)

# Save results
cv2.imwrite('compressed_image.jpg', decompressed_image)

# Display images
cv2.imshow("Original Image", image)
cv2.imshow("Decompressed Image", decompressed_image)

print(f"PSNR between Original and Decompressed Image: {psnr_value} dB")

cv2.waitKey(0)
cv2.destroyAllWindows()