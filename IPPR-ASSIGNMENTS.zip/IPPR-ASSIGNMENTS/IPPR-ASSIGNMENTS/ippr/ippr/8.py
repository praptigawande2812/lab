# 8) Write a code for demonstrating histogram equalization in the image
# Input: 24 bit RGB image
# Expected Output:
# i) 24 bit RGB Equalized image
# ii) Original image histogram and equalized histogram
# Convert to YCrCb and equalize only the Y channel


import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the image
image = cv2.imread('input_image.jpg')  # Replace with your image filename

if image is None:
    print("Error: Could not load image.")
    exit()

# Convert to YCrCb color space
img_ycrcb = cv2.cvtColor(image, cv2.COLOR_BGR2YCrCb)

# Split the channels
y, cr, cb = cv2.split(img_ycrcb)

# Equalize the Y channel
y_eq = cv2.equalizeHist(y)

# Merge back the equalized Y with Cr and Cb
img_eq = cv2.merge((y_eq, cr, cb))

# Convert back to BGR color space
image_equalized = cv2.cvtColor(img_eq, cv2.COLOR_YCrCb2BGR)

# Save the result
cv2.imwrite('hist_equalized.jpg', image_equalized)

# Plot histograms for original and equalized image
plt.figure(figsize=(12, 6))

for i, col in enumerate(('b', 'g', 'r')):
    plt.subplot(2, 3, i + 1)
    hist_orig = cv2.calcHist([image], [i], None, [256], [0, 256])
    plt.plot(hist_orig, color=col)
    plt.title(f'Original {col.upper()} Histogram')
    plt.xlim([0, 256])

    plt.subplot(2, 3, i + 4)
    hist_eq = cv2.calcHist([image_equalized], [i], None, [256], [0, 256])
    plt.plot(hist_eq, color=col)
    plt.title(f'Equalized {col.upper()} Histogram')
    plt.xlim([0, 256])

plt.tight_layout()
plt.show()

# Display the images (optional)
cv2.imshow('Original Image', image)
cv2.imshow('Equalized Image', image_equalized)
cv2.waitKey(0)
cv2.destroyAllWindows()
