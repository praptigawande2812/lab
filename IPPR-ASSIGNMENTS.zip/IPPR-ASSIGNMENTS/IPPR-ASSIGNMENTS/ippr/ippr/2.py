# 2) Write a code for obtaining negative of the image.
# Input: 24 bit color image
# Expected output: 24 bit color image
import cv2

# Load the image in color mode (24-bit BGR)
image = cv2.imread('input_image.jpg', cv2.IMREAD_COLOR)

# Check if the image loaded correctly
if image is None:
    print("Error: Image not found or unable to load.")
else:
    # Calculate the negative image
    negative_image = 255 - image

    # Save and display the result
    cv2.imwrite('negative_image.jpg', negative_image)
    cv2.imshow('Original Image', image)
    cv2.imshow('Negative Image', negative_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
