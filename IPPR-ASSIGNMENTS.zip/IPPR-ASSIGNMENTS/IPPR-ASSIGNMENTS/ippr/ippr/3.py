# 3) Write a code for obtaining CMY equivalent of the image
# Input: 24 bit RGB image
# Expected output: 24 bit CMY image
import cv2
import numpy as np

# Load the image (BGR format by default)
image_bgr = cv2.imread('input_image.jpg')

# Check if the image loaded successfully
if image_bgr is None:
    print("Error: Image not found or unable to load.")
else:
    # Convert BGR to RGB
    image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)

    # Convert RGB to CMY
    image_cmy = 255 - image_rgb

    # Save and display the result (convert back to BGR for OpenCV display)
    image_cmy_bgr = cv2.cvtColor(image_cmy, cv2.COLOR_RGB2BGR)
    cv2.imwrite('cmy_image.jpg', image_cmy_bgr)
    
    cv2.imshow('Original RGB Image', image_bgr)
    cv2.imshow('CMY Equivalent Image', image_cmy_bgr)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
