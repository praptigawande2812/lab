import os
import cv2
import numpy as np
import joblib

data = []
labels = []

base_path = "dataset"  

for label in os.listdir(base_path):
    folder_path = os.path.join(base_path, label)
    if not os.path.isdir(folder_path):
        continue
    for img_file in os.listdir(folder_path):
        img_path = os.path.join(folder_path, img_file)
        img = cv2.imread(img_path)
        if img is None:
            continue
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        _, thresh = cv2.threshold(blurred, 127, 255, cv2.THRESH_BINARY_INV)
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            cnt = max(contours, key=cv2.contourArea)
            hu = cv2.HuMoments(cv2.moments(cnt)).flatten()
            data.append(hu)
            labels.append(label)

# Save features and labels
joblib.dump((np.array(data), np.array(labels)), "features_labels.pkl")
print("Feature extraction completed and saved.")
