from flask import Flask, render_template, request, redirect, url_for
import os
import cv2
import numpy as np
import joblib
from predict_leaf import predict_leaf  # Import the prediction function

app = Flask(__name__)

# Set up the upload folder and allowed file extensions
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Function to check allowed file extensions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('index.html')  # Landing page with upload form

@app.route('/upload', methods=['POST'])
def upload_image():
    if 'file' not in request.files:
        return redirect(request.url)
    file = request.files['file']
    if file.filename == '':
        return redirect(request.url)
    if file and allowed_file(file.filename):
        filename = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(filename)
        
        # Make a prediction using the uploaded image
        prediction = predict_leaf(filename)
        
        return render_template('result.html', filename=file.filename, prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True)
