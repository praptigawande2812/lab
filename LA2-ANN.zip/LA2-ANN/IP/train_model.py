import joblib
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Load features and labels
data, labels = joblib.load("features_labels.pkl")

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.2, random_state=42)

# Train KNN classifier
model = KNeighborsClassifier(n_neighbors=3)
model.fit(X_train, y_train)

# Test accuracy
predictions = model.predict(X_test)
acc = accuracy_score(y_test, predictions)
print(f"Model trained. Accuracy on test set: {acc*100:.2f}%")

# Save model
joblib.dump(model, "leaf_model.pkl")
