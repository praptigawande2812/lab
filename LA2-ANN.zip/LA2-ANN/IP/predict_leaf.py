import cv2
import numpy as np
import joblib

# Load trained model
model = joblib.load("leaf_model.pkl")

# Function to make prediction
def predict_leaf(image_path):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("Image not found or invalid")

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    _, thresh = cv2.threshold(blurred, 127, 255, cv2.THRESH_BINARY_INV)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if not contours:
        raise ValueError("No contours found in the image")
    
    cnt = max(contours, key=cv2.contourArea)
    hu = cv2.HuMoments(cv2.moments(cnt)).flatten().reshape(1, -1)

    # Make prediction
    prediction = model.predict(hu)
    
    return prediction[0]
